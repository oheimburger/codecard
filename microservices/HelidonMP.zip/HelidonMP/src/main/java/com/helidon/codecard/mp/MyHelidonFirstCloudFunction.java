package com.helidon.codecard.mp;


import java.util.Collections;

import javax.json.Json;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;

import io.helidon.common.http.Http;
import io.helidon.config.Config;
import io.helidon.webserver.Routing;
import io.helidon.webserver.ServerRequest;
import io.helidon.webserver.ServerResponse;
import io.helidon.webserver.Service;

public class MyHelidonFirstCloudFunction implements Service {
	
    private String subtitle;
    private String title;
    private String bodytext;
    private String icon;
    private String backgroundColor;
    private static final JsonBuilderFactory JSON = Json.createBuilderFactory(Collections.emptyMap());

    MyHelidonFirstCloudFunction(Config config) {
        this.subtitle = config.get("app.subtitle").asString().orElse("No Subtitle");
        this.title = config.get("app.title").asString().orElse("No title");
        this.bodytext = config.get("app.bodytext").asString().orElse("No bodytext");
        this.icon = config.get("app.icon").asString().orElse("No icon");
        this.backgroundColor = config.get("app.backgroundColor").asString().orElse("No backgroundColor");
    }

    @Override
    public void update(Routing.Rules rules) {
        rules
            .get("/", this::getDefaultMessageHandler)
            .get("/{name}", this::getMessageHandler)
            .put("/{name}/title/subtitle/bodytext", this::updateContentHandler);
    }

    private void getDefaultMessageHandler(ServerRequest request, ServerResponse response) {
        sendResponse(response, "!!");
    }

    
    private void getMessageHandler(ServerRequest request, ServerResponse response) {
        String name = request.path().param("name");
        sendResponse(response, name);
    }

    private void sendResponse(ServerResponse response, String name) {
        String newname = String.format(" %s!", name);
        
        JsonObject returnObject = JSON.createObjectBuilder().add("template", "template1")
        		                                            .add("title", title + newname +"!")
        		                                            .add("subtitle", subtitle)
        		                                            .add("bodytext", bodytext)
        		                                            .add("icon", icon)
        		                                            .add("backgroundColor",backgroundColor).build();
        response.send(returnObject+"\n");
    }

    private void updateSubtitleFromJson(JsonObject jo, ServerRequest request, ServerResponse response) {
    	
        if (!jo.containsKey("title") || !jo.containsKey("subtitle") || !jo.containsKey("bodytext")) {
        	        JsonObject jsonErrorObject = JSON.createObjectBuilder()
                                                     .add("error", "No title or subtitle or bodytext was provided")
                                                     .build();
        	        response.status(Http.Status.BAD_REQUEST_400).send(jsonErrorObject);
        	        return;
        }

        title = jo.getString("title");
        subtitle = jo.getString("subtitle");
        bodytext = jo.getString("bodytext");
        response.status(Http.Status.NO_CONTENT_204).send();
    }
   
    private void updateContentHandler(ServerRequest request, ServerResponse response) {
        request.content().as(JsonObject.class).thenAccept(jo -> updateSubtitleFromJson(jo, request, response));
    }

}